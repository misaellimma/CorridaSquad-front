export interface auxiliar {
    id: number,
    nome: string,
    id_mecanico: number,
    id_equipe: number
}
export interface carro {
    id: number,
    descricao: string,
    numero: string,
    id_equipe: number
}
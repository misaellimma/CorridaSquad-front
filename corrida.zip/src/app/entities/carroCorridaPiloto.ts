export interface carroCorridaPiloto {
    id: number,
    id_carro: number,
    id_corrida: number,
    id_piloto: number
}
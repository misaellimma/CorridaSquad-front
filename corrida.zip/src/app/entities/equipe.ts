export interface equipe {
    id: number,
    nome: string
}
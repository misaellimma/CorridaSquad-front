export interface mecanico {
  id: number,
  nome: string,
  id_equipe: number
}

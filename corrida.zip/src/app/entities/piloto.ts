export interface piloto {
    id: number,
    nome: string,
    id_equipe: number
}
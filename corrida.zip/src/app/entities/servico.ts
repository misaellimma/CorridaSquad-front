export interface servico {
    id: number,
    descricao: string,
    id_mecanico: number,
    id_carro: number
}
